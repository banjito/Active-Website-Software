# Switchgear Inspection Report Generator

This Python script generates standardized switchgear inspection reports with temperature correction factors and comprehensive test data.

## Features

- Visual and mechanical inspection tracking
- Insulation resistance measurements with temperature correction
- Contact resistance measurements
- Automated pass/fail status based on industry thresholds
- Excel report generation with multiple worksheets

## Requirements

- Python 3.7+
- Dependencies listed in requirements.txt

## Installation

1. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

## Usage

```python
from SwitchgearInspectionReport import SwitchgearInspectionReport

# Create a new report
report = SwitchgearInspectionReport()
report.create_new_report(
    customer="ABC Electric",
    address="123 Power Ave, Voltage City, CA 90210",
    user="John Technician",
    job_number="SG-2023-001",
    technicians="John Doe, Jane Smith",
    temperature_f=75,
    substation="Main Distribution"
)

# Update visual inspection data
report.update_visual_mechanical_inspection("Enclosure Exterior", "PASS")
report.update_visual_mechanical_inspection("Enclosure Interior", "FAIL", "Dust accumulation")

# Update electrical test data
report.update_insulation_resistance("Phase_A", 500)  # 500 MΩ
report.update_insulation_resistance("Phase_B", 450)

report.update_contact_resistance("Phase_A", 42)  # 42 μΩ
report.update_contact_resistance("Phase_B", 45)

# Add comments
report.update_comments("Interior requires cleaning due to dust accumulation.")

# Set overall status
report.set_pass_fail_status("FAIL")

# Export to Excel
report.export_to_excel("Switchgear_Inspection_Report.xlsx")
```

## Temperature Correction

The script automatically applies temperature correction factors to insulation resistance measurements based on the ambient temperature provided during report creation. The correction uses the formula:

```
R_corrected = R_measured * TCF
```

Where TCF is the Temperature Correction Factor for the given temperature, referenced to 20°C.

## Report Structure

The generated Excel report contains the following worksheets:

1. **Report Info** - Basic information about the inspection
2. **Visual Inspection** - Results of visual and mechanical inspection
3. **Insulation Resistance** - Insulation resistance measurements with temperature correction
4. **Contact Resistance** - Contact resistance measurements
5. **Comments** - Overall comments and pass/fail status 