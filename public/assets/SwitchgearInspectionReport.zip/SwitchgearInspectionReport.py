import pandas as pd
import numpy as np
from datetime import datetime
import os

class SwitchgearInspectionReport:
    def __init__(self):
        # Initialize dataframes to hold sheet data
        self.report_info = pd.DataFrame()
        self.visual_mechanical = pd.DataFrame()
        self.insulation_resistance = pd.DataFrame()
        self.contact_resistance = pd.DataFrame()
        self.comments = ""
        self.pass_fail = ""
        
        # Load reference tables
        self._load_temperature_conversion_table()
        self._load_tcf_table()
        self._load_dropdown_options()
        
        # Initialize with empty data
        self._initialize_inspection_data()
    
    def _load_temperature_conversion_table(self):
        # Create temperature conversion table (°F to °C)
        fahrenheit = np.arange(0, 121, 1)
        celsius = (fahrenheit - 32) * 5/9
        
        self.temp_conversion = pd.DataFrame({
            'fahrenheit': fahrenheit,
            'celsius': celsius.round(1)
        })
    
    def _load_tcf_table(self):
        # Temperature Correction Factors for insulation resistance measurements
        # Sample data based on typical correction factors (20°C reference)
        temp_c = np.arange(0, 61, 5)
        correction_factors = [3.56, 2.50, 1.74, 1.30, 1.00, 0.74, 0.57, 0.45, 0.36, 0.29, 0.24, 0.19, 0.15]
        
        self.tcf_table = pd.DataFrame({
            'temperature_c': temp_c,
            'correction_factor': correction_factors
        })
    
    def _load_dropdown_options(self):
        # Create dropdown options
        self.status_options = ["PASS", "FAIL", "N/A"]
        
        self.visual_mechanical_items = [
            "Enclosure Exterior", "Enclosure Interior", "Bus Bars", 
            "Circuit Breakers", "Insulators", "Connections", 
            "Control Wiring", "Grounding", "Interlocks", 
            "Auxiliary Devices", "Labeling", "Ventilation"
        ]
        
        self.insulation_resistance_phases = [
            "Phase_A", "Phase_B", "Phase_C", 
            "Phase_AB", "Phase_BC", "Phase_CA"
        ]
        
        self.contact_resistance_phases = [
            "Phase_A", "Phase_B", "Phase_C"
        ]
    
    def get_temperature_celsius(self, temp_fahrenheit):
        # Convert Fahrenheit to Celsius
        closest_f = self.temp_conversion['fahrenheit'].iloc[(self.temp_conversion['fahrenheit'] - temp_fahrenheit).abs().argsort()[0]]
        return self.temp_conversion.loc[self.temp_conversion['fahrenheit'] == closest_f, 'celsius'].values[0]
    
    def get_temperature_correction_factor(self, temp_celsius):
        # Get correction factor for temperature
        # Find closest temperature in table
        closest_temp = self.tcf_table['temperature_c'].iloc[(self.tcf_table['temperature_c'] - temp_celsius).abs().argsort()[0]]
        return self.tcf_table.loc[self.tcf_table['temperature_c'] == closest_temp, 'correction_factor'].values[0]
    
    def correct_resistance_value(self, resistance_value, temp_celsius):
        # Apply temperature correction to resistance value
        # Formula: R_corrected = R_measured * TCF
        correction_factor = self.get_temperature_correction_factor(temp_celsius)
        return resistance_value * correction_factor
    
    def create_new_report(self, customer=None, address=None, user=None, date=None, job_number=None,
                         technicians=None, temperature_f=None, substation=None):
        """
        Create a new switchgear inspection report with basic information
        """
        # Use current date if not provided
        if date is None:
            date = datetime.now().strftime("%Y-%m-%d")
            
        # Create report info dataframe
        self.report_info = pd.DataFrame({
            'field': ['Customer', 'Address', 'User', 'Date', 'Job Number', 'Technicians', 'Temperature (°F)', 'Substation'],
            'value': [customer, address, user, date, job_number, technicians, temperature_f, substation]
        })
        
        # If temperature is provided, calculate celsius value
        if temperature_f is not None:
            self.temperature_c = self.get_temperature_celsius(temperature_f)
        else:
            self.temperature_c = None
            
        # Initialize inspection data
        self._initialize_inspection_data()
        
        return self
    
    def _initialize_inspection_data(self):
        """
        Initialize dataframes with default values
        """
        # Visual and mechanical inspection
        self.visual_mechanical = pd.DataFrame({
            'item': self.visual_mechanical_items,
            'status': ['N/A'] * len(self.visual_mechanical_items),
            'notes': [''] * len(self.visual_mechanical_items)
        })
        
        # Insulation resistance test
        self.insulation_resistance = pd.DataFrame({
            'phase': self.insulation_resistance_phases,
            'value': [0] * len(self.insulation_resistance_phases),
            'unit': ['MΩ'] * len(self.insulation_resistance_phases),
            'corrected_value': [0] * len(self.insulation_resistance_phases),
            'status': ['N/A'] * len(self.insulation_resistance_phases)
        })
        
        # Contact resistance test
        self.contact_resistance = pd.DataFrame({
            'phase': self.contact_resistance_phases,
            'value': [0] * len(self.contact_resistance_phases),
            'unit': ['μΩ'] * len(self.contact_resistance_phases),
            'status': ['N/A'] * len(self.contact_resistance_phases)
        })
        
        # Reset comments and pass/fail status
        self.comments = ""
        self.pass_fail = "N/A"
    
    def update_visual_mechanical_inspection(self, item, status, notes=""):
        """
        Update visual and mechanical inspection status
        """
        if item in self.visual_mechanical['item'].values:
            idx = self.visual_mechanical[self.visual_mechanical['item'] == item].index[0]
            self.visual_mechanical.at[idx, 'status'] = status
            self.visual_mechanical.at[idx, 'notes'] = notes
    
    def update_insulation_resistance(self, phase, value, unit='MΩ'):
        """
        Update insulation resistance test values
        """
        if phase in self.insulation_resistance['phase'].values:
            idx = self.insulation_resistance[self.insulation_resistance['phase'] == phase].index[0]
            self.insulation_resistance.at[idx, 'value'] = value
            self.insulation_resistance.at[idx, 'unit'] = unit
            
            # Apply temperature correction if temperature is available
            if self.temperature_c is not None:
                corrected = self.correct_resistance_value(value, self.temperature_c)
                self.insulation_resistance.at[idx, 'corrected_value'] = corrected
                
                # Set status based on corrected value (example threshold: 100 MΩ)
                self.insulation_resistance.at[idx, 'status'] = "PASS" if corrected >= 100 else "FAIL"
            else:
                # Set status based on uncorrected value if temperature not available
                self.insulation_resistance.at[idx, 'status'] = "PASS" if value >= 100 else "FAIL"
    
    def update_contact_resistance(self, phase, value):
        """
        Update contact resistance test values
        """
        if phase in self.contact_resistance['phase'].values:
            idx = self.contact_resistance[self.contact_resistance['phase'] == phase].index[0]
            self.contact_resistance.at[idx, 'value'] = value
            
            # Set status based on value (example threshold: 50 μΩ)
            self.contact_resistance.at[idx, 'status'] = "PASS" if value <= 50 else "FAIL"
    
    def update_comments(self, comments):
        """
        Update comments section
        """
        self.comments = comments
    
    def set_pass_fail_status(self, status):
        """
        Set overall pass/fail status
        """
        self.pass_fail = status
    
    def export_to_excel(self, filename):
        """
        Export report to Excel file
        """
        # Create a Pandas Excel writer using XlsxWriter as the engine
        writer = pd.ExcelWriter(filename, engine='xlsxwriter')
        
        # Write each dataframe to a different worksheet
        self.report_info.to_excel(writer, sheet_name='Report Info', index=False)
        self.visual_mechanical.to_excel(writer, sheet_name='Visual Inspection', index=False)
        self.insulation_resistance.to_excel(writer, sheet_name='Insulation Resistance', index=False)
        self.contact_resistance.to_excel(writer, sheet_name='Contact Resistance', index=False)
        
        # Create a comments sheet
        comments_df = pd.DataFrame({
            'field': ['Comments', 'Overall Status'],
            'value': [self.comments, self.pass_fail]
        })
        comments_df.to_excel(writer, sheet_name='Comments', index=False)
        
        # Close the Pandas Excel writer and output the Excel file
        writer.close()
        
        return filename


# Example usage
if __name__ == "__main__":
    # Create a new report
    report = SwitchgearInspectionReport()
    report.create_new_report(
        customer="ABC Electric",
        address="123 Power Ave, Voltage City, CA 90210",
        user="John Technician",
        job_number="SG-2023-001",
        technicians="John Doe, Jane Smith",
        temperature_f=75,
        substation="Main Distribution"
    )
    
    # Update visual inspection data
    report.update_visual_mechanical_inspection("Enclosure Exterior", "PASS")
    report.update_visual_mechanical_inspection("Enclosure Interior", "FAIL", "Dust accumulation")
    report.update_visual_mechanical_inspection("Bus Bars", "PASS")
    report.update_visual_mechanical_inspection("Circuit Breakers", "PASS")
    report.update_visual_mechanical_inspection("Insulators", "PASS")
    report.update_visual_mechanical_inspection("Connections", "FAIL", "Loose connection on phase B")
    report.update_visual_mechanical_inspection("Control Wiring", "PASS")
    report.update_visual_mechanical_inspection("Grounding", "PASS")
    report.update_visual_mechanical_inspection("Interlocks", "PASS")
    report.update_visual_mechanical_inspection("Auxiliary Devices", "PASS")
    report.update_visual_mechanical_inspection("Labeling", "PASS")
    report.update_visual_mechanical_inspection("Ventilation", "PASS")
    
    # Update electrical test data
    report.update_insulation_resistance("Phase_A", 500)  # 500 MΩ
    report.update_insulation_resistance("Phase_B", 450)
    report.update_insulation_resistance("Phase_C", 475)
    report.update_insulation_resistance("Phase_AB", 550)
    report.update_insulation_resistance("Phase_BC", 525)
    report.update_insulation_resistance("Phase_CA", 540)
    
    report.update_contact_resistance("Phase_A", 42)  # 42 μΩ
    report.update_contact_resistance("Phase_B", 45)
    report.update_contact_resistance("Phase_C", 44)
    
    # Add comments
    report.update_comments("Interior requires cleaning due to dust accumulation.")
    
    # Set overall status
    report.set_pass_fail_status("FAIL")
    
    # Export to Excel
    report.export_to_excel("Switchgear_Inspection_Report.xlsx") 